#include<stdio.h>
int main(){
    int x;
FILE *file = fopen("txt.txt","a");
if (file == NULL)
{
  printf("ERROR OPEN FILE !");
  return 0;

}
fprintf(file,"hhhhhhhhhhh",x);
fclose(file);

}