#include <stdio.h>
int main()
{
  // int age;
  // printf("Entre age : ");

  // scanf("%d",&age);

  // if ( age < 18)
  // {
  //     printf("you kids");
  // }else{
  //     printf("you gay");
  // }
  // if (age == 100)
  // {
  //   printf("rak katakol loz bzff");
  // }else{
  //     printf("you kola");
  // }


  // int time;
  // printf("Entre age : ");

  // scanf("%d", &time);

  // if (time < 10)
  // {
  //   printf("Good morning.");
  // }
  // else if (time < 20)
  // {
  //   printf("Good day.");
  // }
  // else
  // {
  //   printf("Good evening.");
  // }
   
  // ila kant time 9al 10 good mornig 
  // ila kant time 9al 20 good evening  xx
  // ila kant fo9  20 good day


























     // ila kan ra9am ta7t 0 Pranti N kbira 
     // ila kan ra9am fo9 0 Printi 7arf P
      
      
   
    
    

    


     




}