#include<stdio.h>
int main (){
    int x;
    
    scanf("%d",&x);
    switch (x)
    {
    case 1:
        printf("hello");
        break;
    case 2:
    printf("thank you");
     break;
     case 3 :
     printf("GoodBy!");
    default:
    printf("error choice (1-3)");
        break;
    }
}   