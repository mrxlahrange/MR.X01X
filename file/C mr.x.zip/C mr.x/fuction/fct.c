#include<stdio.h>
#include<unistd.h>

int main(){

     int r;
    printf("erer",r);
    puts();
    scanf("%d",r);// ila kan string madirch had ramz &
    scanf("%d",&r);
    write(1,r,1);//unistd.h
     




}