#include<stdio.h>
int main (){
   int y;
    for ( int x = 1; x <= 9; x++)
    {
        printf("jadwal darb dyal %d\n",x);
     for (int i = 1; i <= 9; i++)
     {
       printf("%d * %d = %d \n",x,i,x*i);
     }
     printf(" \n");
    }














    // while (4 < 5)
    // {
    //     /* code */
    //     x++;
    // }






















    // do
    // {
    //     /* code */
    // } while (x != 3);
    
    
}