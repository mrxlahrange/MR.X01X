#include<stdio.h>

int main(){
  
    int a;//%d %i
    char b = 'h' ;//%s
    char bb[4][5];//%c
    float v ; //%f
    double h; //%lf
 //////////////////////////////////
    int q  = 7;
   printf("you %d  \n",q);   
//////////////////////////////////
   float w = 22.14;
   printf("you %f  \n",w);   
   /////////////////////////////////
   char ff = 'z';
   printf("you %c  \n",ff);   

///////////////////////////////
char hw []= {
    "ziko"
};
   printf("you %s  \n",hw);   

//////////////////
double o = 340;
   printf("you %lf  \n",o);   


   
}