# Welcome and coding C .
* **Discription**  

**The Little Prince" by Antoine de Saint-Exupéry – A poetic tale with deep philosophical themes, perfect for all ages.
"Animal Farm" by George Orwell – A short allegorical novella about power and politics.
"Of Mice and Men" by John Steinbeck – A moving story of friendship and dreams.  
Would you prefer something fictional, educational, or religious? I can help you find the perfect short read.**  


 `let = 0;`    
`printf("hello");`
## Parte 1 :
```css
*{
    margin: 0;
    padding: 0;
  }
  .page1{
    display: grid;
    grid-template-columns: 1fr 1fr;
    height: 100vh;
  }
  .hed1{
    background: #000;
    color: white;
  }
  .hed2{
    background: rgb(38, 113, 32);
  }
```
## Parte 2 :

```c
#include<stdio.h>
int main(){
    int x;
FILE *file = fopen("txt.txt","a");
if (file == NULL)
{
  printf("ERROR OPEN FILE !");
  return 0;

}
fprintf(file,"hhhhhhhhhhh",x);
fclose(file);

}

```
## Parte 3 :

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title></title>
</head>
<body>
  <img src="h4x.png" alt="png">
  <div class="page1">
    <div class="hed1">
      <h1>hello</h1>
    </div>
    <div class="hed2">
      <h1>welcome</h1>
    </div>
  </div>
</body>
<style>
  *{
    margin: 0;
    padding: 0;
  }
  .page1{
    display: grid;
    grid-template-columns: 1fr 1fr;
    height: 100vh;
  }
  .hed1{
    background: #000;
    color: white;
  }
  .hed2{
    background: rgb(38, 113, 32);
  }
</style>
</html>
```
